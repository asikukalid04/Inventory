﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Office.Interop

Public Class payform
    Public ourconn As New MySqlConnection("Server=localhost;Uid=root;Database=sacodb;Port=3306;")
    Public MyDa As New MySqlDataAdapter
    Public DtaSet As New DataSet
    Dim changes As DataSet
    Dim cmdBuilder As MySqlCommandBuilder
    Private MyDatabalance As New DataTable
    Private Mybalance As New DataTable
    Private MyRowPosition As Integer = 0


    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click

        Try
            Dim str As String = "INSERT INTO paytb(name,amountpaid,balance,contact,date,memberID) VALUES('" & txtname.Text & "','" & txtamount.Text & "','" & txtbalance.Text & "','" & txtcontact.Text & "','" & DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") & "','" & txtID.Text & "')"
            ourconn.Open()
            Dim mysc As New MySqlCommand(str, ourconn)
            mysc.ExecuteNonQuery()
            MsgBox("Loan Payment successfully Captured", MsgBoxStyle.Information)
            ourconn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            ourconn.Close()
        End Try
        btnClear.PerformClick()

        btnrefresh.PerformClick()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtname.Clear()
        txtloan.Clear()
        txtcurrentba.Clear()
        txtID.Clear()
        txtcontact.Clear()

    End Sub


    Public Sub DataConnection(ByVal DgV As DataGridView)

        With DgV
            .DataSource = DtaSet
            .DataMember = "paytb"
            .Columns(0).DataPropertyName = "payID"

            .Columns(0).HeaderText = "ID"
            .Columns(1).HeaderText = "NAME"
            .Columns(2).HeaderText = "AMOUNT PAID"
            .Columns(3).HeaderText = "BALANCE"
            .Columns(4).HeaderText = "CONTACT"
            .Columns(5).HeaderText = "DATE"
            .Columns(6).HeaderText = "MEMBER ID"

            .MultiSelect = False
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .ShowRowErrors = False
            .ShowCellErrors = False
            .AllowUserToAddRows = False ' Disabled or hide (*) Symbol...
            .AllowUserToResizeColumns = False 'Disable HearderText Resize Column...
            .AllowUserToResizeRows = False 'Disabled  row resize...
            .RowHeadersVisible = False 'To hide Left indicator...
            .DefaultCellStyle.SelectionBackColor = Color.SteelBlue  'Selection backcolor....
            .DefaultCellStyle.ForeColor = Color.Black  'Selection backcolor....
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGoldenrodYellow 'Alternating Backcolor

        End With
    End Sub

    Private Sub Btnnewstudent_Click(sender As Object, e As EventArgs)
        txtamount.Clear()
        txtname.Clear()
    End Sub

    Private Sub Btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        With MyDa
            ourconn.Open()
            .SelectCommand = New MySqlCommand
            .SelectCommand.CommandText = "SELECT * FROM paytb"
            .SelectCommand.Connection = ourconn
            DtaSet.Clear()
            MyDa.Fill(DtaSet, "paytb")

            ourconn.Close()
        End With
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        If DtaSet.Tables("paytb").Rows.Count = 0 Then
            MsgBox("No record's to delete...", MsgBoxStyle.Information, "No record's")
            Exit Sub
        End If
        If Me.DgV.CurrentRow.Selected = 0 Then
            MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
            Exit Sub
        End If

        If MsgBox("Do you want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Confirmation...") = MsgBoxResult.Yes Then
            MsgBox(Me.DgV.SelectedRows(0).Cells(1).Value & " " & Me.DgV.SelectedRows(0).Cells(2).Value & "  Successfully deleted...", MsgBoxStyle.Information, "Deleted...")
            Me.BindingContext(DtaSet, "paytb").EndCurrentEdit()
            Me.BindingContext(DtaSet, "paytb").RemoveAt(Me.BindingContext(DtaSet, "paytb").Position)
            MyDa.Update(DtaSet, "paytb")

        Else
            MsgBox("Deletion canceled...", MsgBoxStyle.Information, "Canceled..")
        End If
    End Sub

    Private Sub Btnexport_Click(sender As Object, e As EventArgs) Handles btnexport.Click
        DgV.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True
            rowsTotal = DgV.RowCount - 1
            colsTotal = DgV.Columns.Count - 1

            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = DgV.Columns(iC).HeaderText
                Next

                For I = 0 To rowsTotal 'REMOVED THE - 1 to print the lasr row for the total
                    For j = 0 To colsTotal 'REMOVED THE - 1 to print the lasr column for the telephone
                        .Cells(I + 2, j + 1).value = DgV.Rows(I).Cells(j).Value
                    Next j
                Next I

                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 10
                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With

        Catch ex As Exception
            MsgBox("Export Excel Error " & ex.Message)
        Finally
            'RELEASE ALLOACTED RESOURCES  
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing

        End Try
    End Sub

    Private Sub DgV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgV.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            If Me.DgV.CurrentRow.Selected = 0 Then
                MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
                Exit Sub
            End If
            Me.BindingContext(DtaSet, "paytb").ResumeBinding()
            'Me.BindingContext(DtaSet, "Students").RemoveAt(Me.BindingContext(DtaSet, "Students").Position)
            MyDa.Update(DtaSet, "paytb")

            DgV.DataSource = DtaSet.Tables(0)
            MyDa.Fill(DtaSet)
            cmdBuilder = New MySqlCommandBuilder(MyDa)
            changes = DtaSet.GetChanges()
            If changes IsNot Nothing Then

                MyDa.Update(changes)
            End If
            MsgBox("Changes Done")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub payform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            With ourconn
                With MyDa
                    .SelectCommand = New MySqlCommand
                    .SelectCommand.CommandText = "SELECT * FROM paytb"
                    .SelectCommand.Connection = ourconn
                    Dim Ole As New MySqlCommandBuilder(MyDa)
                    DtaSet.Clear()
                    .Fill(DtaSet, "paytb")
                    Call DataConnection(Me.DgV)
                End With
            End With

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Critical, "Error...Here...........")
        Finally
            ourconn.Close()
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtamount.TextChanged

    End Sub


    Private Sub PAYMENT_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Public Sub callbalance()


        If MyDatabalance.Rows.Count = 0 Then

            txtname.Text = ""
            txtamount.Text = ""
            MessageBox.Show("Sorry ,Member With Loan ID-" & txtID.Text & " Does Not Exisit", "Information !")
            Exit Sub
        End If

        MyRowPosition = MyDatabalance.Rows.Count - 1
        ' txtID.Text = MyDataTbl.Rows(MyRowPosition)("ID").ToString()
        txtname.Text = MyDatabalance.Rows(MyRowPosition)("name").ToString()
        txtloan.Text = MyDatabalance.Rows(MyRowPosition)("returnamount").ToString()

    End Sub
    Public Sub balance()


        If Mybalance.Rows.Count = 0 Then


            txtcurrentba.Text = ""

            Exit Sub
        End If

        MyRowPosition = Mybalance.Rows.Count - 1

        txtcurrentba.Text = Mybalance.Rows(MyRowPosition)("balance").ToString()
    End Sub
    Private Sub balance(sender As Object, e As EventArgs) Handles txtamount.MouseLeave



    End Sub

    Private Sub txtbalance_TextChanged(sender As Object, e As EventArgs) Handles txtbalance.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If txtcurrentba.Text = "" Then
            txtcurrentba.Text = 0
            txtbalance.Text = CInt(txtloan.Text) - CInt(txtamount.Text)
        End If
        If CInt(txtcurrentba.Text) > 0 And CInt(txtcurrentba.Text) < CInt(txtloan.Text) Then

            txtbalance.Text = CInt(txtcurrentba.Text) - CInt(txtamount.Text)
        End If

    End Sub




    Private Sub cc(sender As Object, e As EventArgs) Handles txtID.Leave



    End Sub

    Private Sub FinancialInformToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinancialInformToolStripMenuItem.Click
        membership.Show()
        Me.Hide()

    End Sub

    Private Sub ApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplicationToolStripMenuItem.Click
        save.Show()
        Me.Hide()

    End Sub

    Private Sub OanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OanToolStripMenuItem.Click
        loan.Show()
        Me.Hide()

    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click

    End Sub

    Private Sub AdminToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdminToolStripMenuItem.Click
        user2.Show()
        Me.Hide()

    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub txtname_MouseClick(sender As Object, e As MouseEventArgs) Handles txtname.MouseClick

    End Sub

    Private Sub txtcontact_Click(sender As Object, e As EventArgs) Handles txtcontact.Click

    End Sub

    Private Sub txtID_MouseLeave(sender As Object, e As EventArgs) Handles txtID.MouseLeave
        ourconn.Open()
        With MyDa

            .SelectCommand = New MySqlCommand
            .SelectCommand.CommandText = "SELECT  balance FROM paytb WHERE (date IN (SELECT MAX(date) AS Expr1 FROM paytb AS paytb_1  WHERE (memberID =" & txtID.Text & " )))"
            .SelectCommand.Connection = ourconn

            MyDa.Fill(Mybalance)



        End With



        With MyDa

            .SelectCommand = New MySqlCommand
            .SelectCommand.CommandText = "SELECT name, returnamount FROM loantb WHERE (date IN (SELECT MAX(date) AS Expr1 FROM loantb AS loanoffers_1  WHERE (MemberID =" & txtID.Text & ")))"
            .SelectCommand.Connection = ourconn
            MyDa.Fill(MyDatabalance)
            Using RDR = .SelectCommand.ExecuteReader

                If RDR.HasRows Then


                    If Not IsDBNull(RDR) Then
                        Me.balance()
                        Me.callbalance()





                    Else


                    End If
                Else

                    MessageBox.Show("Has No currently running loan", "Information !", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtname.Clear()
                    txtloan.Clear()
                    txtcurrentba.Clear()
                    txtID.Clear()
                    txtcontact.Clear()


                End If



            End Using

        End With


        ourconn.Close()
    End Sub
End Class