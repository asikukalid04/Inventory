﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Office.Interop

Public Class loan
   

    Public ourconn As New MySqlConnection("Server=localhost;Uid=root;Database=sacodb;Port=3306")
    Public MyDa As New MySqlDataAdapter
    Public DtaSet As New DataSet
    Dim changes As DataSet
    Dim cmdBuilder As MySqlCommandBuilder




    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click

        ourconn.Open()


        Dim cmd As MySqlCommand = New MySqlCommand("SELECT amount FROM loantb WHERE MemberID = @MemberID", ourconn)
        cmd.Parameters.AddWithValue("@MemberID", txtID.Text)

        Using RDR1 = cmd.ExecuteReader()
            If txtID.Text = "" Then
                MessageBox.Show("Please Enter Member ID", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                If RDR1.HasRows Then
                    RDR1.Read()
                    ' Check if the "amount" column exists in the result set
                    Dim amount As Decimal
                    If Decimal.TryParse(RDR1("amount").ToString(), amount) Then
                        If amount > 10000 Then
                            MessageBox.Show("Have a Running Loan of:" & amount, "Valid Member", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Else
                            MessageBox.Show("Amount is not a valid numeric value.", "Invalid Member", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                        ourconn.Close()
                    Else


                    End If

                Else
                    Try
                        RDR1.Close()
                        Dim str As String = "INSERT INTO loantb(memberID,name,amount,interest,returnamount,accountNo,payday,date) VALUES('" & txtID.Text & "','" & txtname.Text & "','" & txtamount.Text & "','" & txtnterest.Text & "','" & txtreturn.Text & "','" & txtaccount.Text & "','" & paydate.Text & "','" & date1.Text & "')"

                        Dim mysc As New MySqlCommand(str, ourconn)
                        mysc.ExecuteNonQuery()
                        MsgBox("Loan For '" & txtname.Text & "' Has Been Placed", MsgBoxStyle.Information)

                    Catch ex As Exception
                        MsgBox(ex.Message)

                    End Try
                    ourconn.Close()
                    btnClear.PerformClick()

                    btnrefresh.PerformClick()
                End If


            End If
        End Using
        ourconn.Close()

    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtnterest.Clear()
        txtname.Clear()
        txtaccount.Clear()
        txtamount.Clear()
        txtnterest.Clear()
        txtrange.Clear()
        txtID.Clear()
    End Sub


    Public Sub DataConnection(ByVal DgV As DataGridView)

        With DgV
            .DataSource = DtaSet
            .DataMember = "loantb"
            .Columns(0).DataPropertyName = "loanID"

            .Columns(0).HeaderText = "ID"
            .Columns(1).HeaderText = "NAME"
            .Columns(2).HeaderText = "ACCOUNO"
            .Columns(3).HeaderText = "LOAN"
            .Columns(4).HeaderText = "INTEREST"
            .Columns(5).HeaderText = "RETURN"
            .Columns(6).HeaderText = "PAY DATE"
            .Columns(7).HeaderText = "DATE"
            .MultiSelect = False
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .ShowRowErrors = False
            .ShowCellErrors = False
            .AllowUserToAddRows = False ' Disabled or hide (*) Symbol...
            .AllowUserToResizeColumns = False 'Disable HearderText Resize Column...
            .AllowUserToResizeRows = False 'Disabled  row resize...
            .RowHeadersVisible = False 'To hide Left indicator...
            .DefaultCellStyle.SelectionBackColor = Color.SteelBlue  'Selection backcolor....
            .DefaultCellStyle.ForeColor = Color.Black  'Selection backcolor....
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGoldenrodYellow 'Alternating Backcolor

        End With
    End Sub

    Private Sub Btnnewstudent_Click(sender As Object, e As EventArgs)
        txtnterest.Clear()
        txtname.Clear()
    End Sub

    Private Sub Btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        With MyDa
            ourconn.Open()
            .SelectCommand = New MySqlCommand
            .SelectCommand.CommandText = "SELECT * FROM loantb"
            .SelectCommand.Connection = ourconn
            DtaSet.Clear()
            MyDa.Fill(DtaSet, "loantb")

            ourconn.Close()
        End With
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        If DtaSet.Tables("loantb").Rows.Count = 0 Then
            MsgBox("No record's to delete...", MsgBoxStyle.Information, "No record's")
            Exit Sub
        End If
        If Me.DgV.CurrentRow.Selected = 0 Then
            MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
            Exit Sub
        End If

        If MsgBox("Do you want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Confirmation...") = MsgBoxResult.Yes Then
            MsgBox(Me.DgV.SelectedRows(0).Cells(1).Value & " " & Me.DgV.SelectedRows(0).Cells(2).Value & "Successfully deleted...", MsgBoxStyle.Information, "Deleted...")
            Me.BindingContext(DtaSet, "loantb").EndCurrentEdit()
            Me.BindingContext(DtaSet, "loantb").RemoveAt(Me.BindingContext(DtaSet, "loantb").Position)
            MyDa.Update(DtaSet, "loantb")

        Else
            MsgBox("Deletion canceled...", MsgBoxStyle.Information, "Canceled..")
        End If
    End Sub

    Private Sub Btnexport_Click(sender As Object, e As EventArgs) Handles btnexport.Click
        DgV.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True
            rowsTotal = DgV.RowCount - 1
            colsTotal = DgV.Columns.Count - 1

            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = DgV.Columns(iC).HeaderText
                Next

                For I = 0 To rowsTotal 'REMOVED THE - 1 to print the lasr row for the total
                    For j = 0 To colsTotal 'REMOVED THE - 1 to print the lasr column for the telephone
                        .Cells(I + 2, j + 1).value = DgV.Rows(I).Cells(j).Value
                    Next j
                Next I

                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 10
                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With

        Catch ex As Exception
            MsgBox("Export Excel Error " & ex.Message)
        Finally
            'RELEASE ALLOACTED RESOURCES  
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing

        End Try
    End Sub

    Private Sub DgV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgV.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            If Me.DgV.CurrentRow.Selected = 0 Then
                MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
                Exit Sub
            End If
            Me.BindingContext(DtaSet, "loantb").ResumeBinding()
            'Me.BindingContext(DtaSet, "Students").RemoveAt(Me.BindingContext(DtaSet, "Students").Position)
            MyDa.Update(DtaSet, "loantb")

            DgV.DataSource = DtaSet.Tables(0)
            MyDa.Fill(DtaSet)
            cmdBuilder = New MySqlCommandBuilder(MyDa)
            changes = DtaSet.GetChanges()
            If changes IsNot Nothing Then

                MyDa.Update(changes)
            End If
            MsgBox("Changes Done")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub loan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            With ourconn
                With MyDa
                    .SelectCommand = New MySqlCommand
                    .SelectCommand.CommandText = "SELECT * FROM loantb"
                    .SelectCommand.Connection = ourconn
                    Dim Ole As New MySqlCommandBuilder(MyDa)
                    DtaSet.Clear()
                    .Fill(DtaSet, "loantb")
                    Call DataConnection(Me.DgV)
                End With
            End With

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Critical, "Error...Here...........")
        Finally
            ourconn.Close()
        End Try
    End Sub

    Private Sub FinancialInformToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinancialInformToolStripMenuItem.Click
        Me.Hide()
        membership.Show()

    End Sub

    Private Sub ApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplicationToolStripMenuItem.Click
        Me.Hide()
        save.Show()
    End Sub

    Private Sub OanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OanToolStripMenuItem.Click

    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        Me.Hide()
        payform.Show()
    End Sub

    Private Sub AdminToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdminToolStripMenuItem.Click
        Me.Hide()
        user2.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Form1.Show()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub StudentAccountsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentAccountsToolStripMenuItem.Click
        Fpanel.Show()
        Me.Hide()
    End Sub

    Private Sub compute_Click(sender As Object, e As EventArgs) Handles compute.Click
        Try
            If CInt(txtamount.Text) >= 80000 And CInt(txtamount.Text) <= 190000 And TxtDuration1.Text = "1 Months" Then
                txtrange.Text = "80,000-190,000"
                txtnterest.Text = 6%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.08)
            ElseIf CInt(txtamount.Text) >= 80000 And CInt(txtamount.Text) <= 190000 And TxtDuration1.Text = "2 Months" Then
                txtrange.Text = "100,000-190,000"
                txtnterest.Text = 8%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.1)
            ElseIf CInt(txtamount.Text) >= 80000 And CInt(txtamount.Text) <= 190000 And TxtDuration1.Text = "1 Year" Then
                txtrange.Text = "100,000-190,000"
                txtnterest.Text = 10%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.1)
            End If


            If CInt(txtamount.Text) >= 200000 And CInt(txtamount.Text) <= 290000 And TxtDuration1.Text = "1 Months" Then
                txtrange.Text = "200,000-290,000"
                txtnterest.Text = 8%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.12)
            ElseIf CInt(txtamount.Text) >= 200000 And CInt(txtamount.Text) <= 290000 And TxtDuration1.Text = "2 Months" Then
                txtrange.Text = "200,000-290,000"
                txtnterest.Text = 12%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.14)
            ElseIf CInt(txtamount.Text) >= 200000 And CInt(txtamount.Text) <= 290000 And TxtDuration1.Text = "1 Year" Then
                txtrange.Text = "200,000-290,000"
                txtnterest.Text = 14%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.14)
            End If


            If CInt(txtamount.Text) >= 300000 And CInt(txtamount.Text) <= 390000 And TxtDuration1.Text = "1 Months" Then
                txtrange.Text = "300,000-390,000"
                txtnterest.Text = 10%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.1)

            ElseIf CInt(txtamount.Text) >= 300000 And CInt(txtamount.Text) <= 390000 And TxtDuration1.Text = "2 Months" Then
                txtrange.Text = "300,000-290,000"
                txtnterest.Text = 14%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.16)
            ElseIf CInt(txtamount.Text) >= 300000 And CInt(txtamount.Text) <= 390000 And TxtDuration1.Text = "1 Year" Then
                txtrange.Text = "300,000-290,000"
                txtnterest.Text = 16%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.16)
            End If

            If CInt(txtamount.Text) >= 400000 And CInt(txtamount.Text) <= 1000000 And TxtDuration1.Text = "1 Months" Then
                txtrange.Text = "400,000-1,000,000"
                txtnterest.Text = 12%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.12)
            ElseIf CInt(txtamount.Text) >= 400000 And CInt(txtamount.Text) <= 1000000 And TxtDuration1.Text = "2 Months" Then
                txtrange.Text = "400,000-1,000,000"
                txtnterest.Text = 17%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.2)
            ElseIf CInt(txtamount.Text) >= 400000 And CInt(txtamount.Text) <= 1000000 And TxtDuration1.Text = "1 Year" Then
                txtrange.Text = "400,000-1,000,000"
                txtnterest.Text = 20%

                txtreturn.Text = CInt(txtamount.Text) + (CInt(txtamount.Text) * 0.2)
            End If
        Catch ex As Exception
            MessageBox.Show("Please Input Figures", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub TxtDuration1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TxtDuration1.SelectedIndexChanged

    End Sub

    Private Sub txtID_MouseLeave(sender As Object, e As EventArgs) Handles txtID.MouseLeave
        ourconn.Open()
        Dim cmd As MySqlCommand = New MySqlCommand("SELECT name,accountNo FROM membertb WHERE MemberID = @MemberID", ourconn)
        cmd.Parameters.AddWithValue("@MemberID", txtID.Text)


        Using RDR = cmd.ExecuteReader()
            If txtID.Text = "" Then
                MessageBox.Show("Please Enter Member ID", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                If RDR.HasRows Then
                    RDR.Read()
                    ' Check if the "name" column exists in the result set
                    If Not IsDBNull(RDR("name")) Then
                        txtname.Text = RDR("name").ToString()


                    End If

                    If Not IsDBNull(RDR("accountNo")) Then

                        txtaccount.Text = RDR("accountNo").ToString()

                    End If
                Else
                    MessageBox.Show("MemberID Does Not Exist.Please Register", "Invalid Member ID", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        End Using
        ourconn.Close()
    End Sub

    Private Sub txtamount_MouseLeave(sender As Object, e As EventArgs) Handles txtamount.MouseLeave
        Try
            If CInt(txtamount.Text) < 80000 Then
                MessageBox.Show("Loan Must Not Below Be 80000", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception

        End Try

    End Sub
End Class