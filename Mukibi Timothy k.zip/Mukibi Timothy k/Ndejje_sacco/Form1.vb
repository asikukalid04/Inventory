﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Public ourconn As New MySqlConnection("Server=localhost;Uid=root;Database=sacodb;Port=3306")

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs)
        Me.Close()

    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs)

        save.Show()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        membership.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        save.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        loan.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        payform.Show()
    End Sub

    Private Sub txtpass_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        ourconn.Open()


        Dim cmd As MySqlCommand = New MySqlCommand("SELECT username, password FROM   usertb WHERE   (username ='" & username.Text & "' ) AND (password ='" & password.Text & "')", ourconn)
        Using RDR = cmd.ExecuteReader
            If username.Text = "" Or password.Text = "" Then

                MessageBox.Show("Please Enter All Credentials", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                If RDR.HasRows Then


                    If Not IsDBNull(RDR) Then
                        Fpanel.Show()



                    End If

                Else
                    MessageBox.Show("Invalid User Name Or Password", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)


                End If
            End If





        End Using
        ourconn.Close()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)
        Fpanel.Show()
    End Sub

    Private Sub password_TextChanged(sender As Object, e As EventArgs) Handles password.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
