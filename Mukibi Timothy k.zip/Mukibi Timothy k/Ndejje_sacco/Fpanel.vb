﻿Public Class Fpanel
    Private Sub FinancialInformToolStripMenuItem_Click(sender As Object, e As EventArgs)
        membership.Show()
    End Sub

    Private Sub ApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs)
        save.Show()
    End Sub

    Private Sub OanToolStripMenuItem_Click(sender As Object, e As EventArgs)
        loan.Show()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs)
        payform.Show()
    End Sub

    Private Sub AdminToolStripMenuItem_Click(sender As Object, e As EventArgs)
        user2.Show()
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs)
        Form1.Show()
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub Fpanel_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub StudentAccountsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentAccountsToolStripMenuItem.Click

    End Sub

    Private Sub FinancialInformToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles FinancialInformToolStripMenuItem.Click
        membership.Show()
    End Sub

    Private Sub ApplicationToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ApplicationToolStripMenuItem.Click
        save.Show()
    End Sub

    Private Sub OanToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles OanToolStripMenuItem.Click
        loan.Show()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        payform.Show()
    End Sub

    Private Sub AdminToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles AdminToolStripMenuItem.Click
        user2.Show()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        membership.Show()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        save.Show()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        loan.Show()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        payform.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        user2.Show()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Form1.Show()
    End Sub
End Class