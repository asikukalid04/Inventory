﻿Imports MySql.Data.MySqlClient
Imports Microsoft.Office.Interop

Public Class membership
    Public ourconn As New MySqlConnection("Server=localhost;Uid=root;Database=sacodb;Port=3306")
    Public MyDa As New MySqlDataAdapter
    Public DtaSet As New DataSet
    Dim changes As DataSet
    Dim cmdBuilder As MySqlCommandBuilder




    Private Sub Btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click

        Try
            Dim str As String = "INSERT INTO membertb(name,gender,location,contact,business,accountNo,date) VALUES('" & txtname.Text & "','" & txtgender.Text & "','" & txtaddress.Text & "','" & txtcontact.Text & "','" & txtbusines.Text & "','" & txtaccount.Text & "','" & date1.Text & "')"
            ourconn.Open()
            Dim mysc As New MySqlCommand(str, ourconn)
            mysc.ExecuteNonQuery()
            MsgBox("Member Account created successfully", MsgBoxStyle.Information)
            ourconn.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
            ourconn.Close()
        End Try
        btnClear.PerformClick()

        btnrefresh.PerformClick()
    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtbusines.Clear()
        txtname.Clear()
    End Sub


    Public Sub DataConnection(ByVal DgV As DataGridView)

        With DgV
            .DataSource = DtaSet
            .DataMember = "membertb"
            .Columns(0).DataPropertyName = "memberID"

            .Columns(0).HeaderText = "ID"
            .Columns(1).HeaderText = "NAME"
            .Columns(2).HeaderText = "GENDER"
            .Columns(3).HeaderText = "ADDRESS"
            .Columns(4).HeaderText = "CONTACT"
            .Columns(5).HeaderText = "BUSSINESS"
            .Columns(6).HeaderText = "ACCOUNTNO"
            .Columns(7).HeaderText = "DATE"
            .MultiSelect = False
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .ShowRowErrors = False
            .ShowCellErrors = False
            .AllowUserToAddRows = False ' Disabled or hide (*) Symbol...
            .AllowUserToResizeColumns = False 'Disable HearderText Resize Column...
            .AllowUserToResizeRows = False 'Disabled  row resize...
            .RowHeadersVisible = False 'To hide Left indicator...
            .DefaultCellStyle.SelectionBackColor = Color.SteelBlue  'Selection backcolor....
            .DefaultCellStyle.ForeColor = Color.Black  'Selection backcolor....
            .AlternatingRowsDefaultCellStyle.BackColor = Color.LightGoldenrodYellow 'Alternating Backcolor

        End With
    End Sub

    Private Sub Btnnewstudent_Click(sender As Object, e As EventArgs) Handles btnnewstudent.Click
        txtbusines.Clear()
        txtname.Clear()
    End Sub

    Private Sub Btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        With MyDa
            ourconn.Open()
            .SelectCommand = New MySqlCommand
            .SelectCommand.CommandText = "SELECT * FROM MEMBERTB"
            .SelectCommand.Connection = ourconn
            DtaSet.Clear()
            MyDa.Fill(DtaSet, "MEMBERTB")

            ourconn.Close()
        End With
    End Sub

    Private Sub Btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        If DtaSet.Tables("membertb").Rows.Count = 0 Then
            MsgBox("No record's to delete...", MsgBoxStyle.Information, "No record's")
            Exit Sub
        End If
        If Me.DgV.CurrentRow.Selected = 0 Then
            MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
            Exit Sub
        End If

        If MsgBox("Do you want to delete this record?", MsgBoxStyle.Question + MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2, "Confirmation...") = MsgBoxResult.Yes Then
            MsgBox(Me.DgV.SelectedRows(0).Cells(1).Value & " " & "  Successfully deleted...", MsgBoxStyle.Information, "Deleted...")
            Me.BindingContext(DtaSet, "membertb").EndCurrentEdit()
            Me.BindingContext(DtaSet, "membertb").RemoveAt(Me.BindingContext(DtaSet, "membertb").Position)
            MyDa.Update(DtaSet, "membertb")

        Else
            MsgBox("Deletion canceled...", MsgBoxStyle.Information, "Canceled..")
        End If
    End Sub

    Private Sub Btnexport_Click(sender As Object, e As EventArgs) Handles btnexport.Click
        DgV.RowsDefaultCellStyle.WrapMode = DataGridViewTriState.True
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True
            rowsTotal = DgV.RowCount - 1
            colsTotal = DgV.Columns.Count - 1

            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = DgV.Columns(iC).HeaderText
                Next

                For I = 0 To rowsTotal 'REMOVED THE - 1 to print the lasr row for the total
                    For j = 0 To colsTotal 'REMOVED THE - 1 to print the lasr column for the telephone
                        .Cells(I + 2, j + 1).value = DgV.Rows(I).Cells(j).Value
                    Next j
                Next I

                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 10
                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With

        Catch ex As Exception
            MsgBox("Export Excel Error " & ex.Message)
        Finally
            'RELEASE ALLOACTED RESOURCES  
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing

        End Try
    End Sub

    Private Sub DgV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgV.CellContentClick

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            If Me.DgV.CurrentRow.Selected = 0 Then
                MsgBox("Please select or highlighted record to delete...", MsgBoxStyle.Information, "Select...")
                Exit Sub
            End If
            Me.BindingContext(DtaSet, "membertb").ResumeBinding()
            'Me.BindingContext(DtaSet, "Students").RemoveAt(Me.BindingContext(DtaSet, "Students").Position)
            MyDa.Update(DtaSet, "membertb")

            DgV.DataSource = DtaSet.Tables(0)
            MyDa.Fill(DtaSet)
            cmdBuilder = New MySqlCommandBuilder(MyDa)
            changes = DtaSet.GetChanges()
            If changes IsNot Nothing Then

                MyDa.Update(changes)
            End If
            MsgBox("Changes Done")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub membership_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            With ourconn
                With MyDa
                    .SelectCommand = New MySqlCommand
                    .SelectCommand.CommandText = "SELECT * FROM membertb"
                    .SelectCommand.Connection = ourconn
                    Dim Ole As New MySqlCommandBuilder(MyDa)
                    DtaSet.Clear()
                    .Fill(DtaSet, "membertb")
                    Call DataConnection(Me.DgV)
                End With
            End With

        Catch ex As Exception
            MsgBox(ex.Message(), MsgBoxStyle.Critical, "Error...Here...........")
        Finally
            ourconn.Close()
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtbusines.TextChanged

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            txtgender.Text = "Male"
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            txtgender.Text = "Female"
        End If
    End Sub
    Private Sub memberbtn_Click_1(sender As Object, e As EventArgs)

    End Sub



    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
    Private Sub FinancialInformToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinancialInformToolStripMenuItem.Click
      
    End Sub

    Private Sub ApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApplicationToolStripMenuItem.Click
        save.Show()
        Me.Hide()

    End Sub

    Private Sub OanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OanToolStripMenuItem.Click
        loan.Show()
        Me.Hide()

    End Sub

    Private Sub PaymentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaymentToolStripMenuItem.Click
        payform.Show()
        Me.Hide()

    End Sub

    Private Sub AdminToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdminToolStripMenuItem.Click
        user2.Show()
        Me.Hide()

    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Form1.Show()
        Me.Hide()

    End Sub
End Class