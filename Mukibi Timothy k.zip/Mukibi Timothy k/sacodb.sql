-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2023 at 09:09 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sacodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `loantb`
--

CREATE TABLE `loantb` (
  `loanID` int(5) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `accountNo` varchar(12) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `interest` int(10) DEFAULT NULL,
  `returnamount` int(10) DEFAULT NULL,
  `date` varchar(10) DEFAULT '',
  `payday` varchar(10) DEFAULT '',
  `memberID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loantb`
--

INSERT INTO `loantb` (`loanID`, `name`, `accountNo`, `amount`, `interest`, `returnamount`, `date`, `payday`, `memberID`) VALUES
(21, 'Kennet Opio', '045665565556', 200000, 8, 224000, '25/10/2023', '25/10/2023', 19),
(23, 'Kennet Opio', '045665565556', 300000, 14, 348000, '27/10/2023', '25/10/2023', 19),
(24, 'ken Jonah', '484949', 400000, 12, 448000, '25/10/2023', '25/10/2023', 20),
(25, 'Odero K', '4525556655', 100000, 6, 108000, '25/10/2023', '25/10/2023', 22),
(26, 'Grace Mary', '42565525565', 200000, 8, 224000, '25/10/2023', '25/10/2023', 24);

-- --------------------------------------------------------

--
-- Table structure for table `membertb`
--

CREATE TABLE `membertb` (
  `memberID` int(10) NOT NULL,
  `name` varchar(20) DEFAULT '',
  `gender` varchar(20) DEFAULT '',
  `location` varchar(20) DEFAULT '',
  `contact` int(20) DEFAULT NULL,
  `business` varchar(20) DEFAULT NULL,
  `accountNo` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membertb`
--

INSERT INTO `membertb` (`memberID`, `name`, `gender`, `location`, `contact`, `business`, `accountNo`, `date`) VALUES
(19, 'Kennet Opio', 'Male', 'Kampala', 2147483647, 'Bus', '045665565556', '25/10/2023'),
(22, 'Odero K', 'Male', 'Kamapala', 75201585, 'Hotel Businss', '4525556655', '25/10/2023'),
(24, 'Grace Mary', 'Female', 'Wakiso', 75201584, 'Botique', '42565525565', '25/10/2023');

-- --------------------------------------------------------

--
-- Table structure for table `paytb`
--

CREATE TABLE `paytb` (
  `payID` int(5) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `amountpaid` int(7) DEFAULT NULL,
  `balance` int(7) DEFAULT NULL,
  `contact` int(12) DEFAULT NULL,
  `date` varchar(10) DEFAULT '',
  `memberID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paytb`
--

INSERT INTO `paytb` (`payID`, `name`, `amountpaid`, `balance`, `contact`, `date`, `memberID`) VALUES
(43, 'ken Jonah', 100000, 348000, 75201858, '2023-10-25', 20),
(44, 'ken Jonah', 100000, 248000, 758555, '2023-10-25', 20),
(45, 'Odero K', 1000, 107000, 752000, '2023-10-25', 22),
(46, 'Grace Mary', 20000, 204000, 752015865, '2023-10-25', 24),
(47, 'Grace Mary', 10000, 194000, 752012554, '2023-10-25', 24);

-- --------------------------------------------------------

--
-- Table structure for table `savetb`
--

CREATE TABLE `savetb` (
  `saveID` int(5) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `accountNo` varchar(10) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `date` varchar(20) DEFAULT '',
  `memberID` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `savetb`
--

INSERT INTO `savetb` (`saveID`, `name`, `accountNo`, `amount`, `date`, `memberID`) VALUES
(30, 'Kennet Opi', '045245565', 4000, '25/10/2023', 19),
(31, 'ken Jonah', '45222', 20000, '25/10/2023', 20),
(32, 'Odero K', '1452222', 10000, '25/10/2023', 22),
(33, 'Odero K', '4555856555', 100000, '25/10/2023', 22);

-- --------------------------------------------------------

--
-- Table structure for table `usertb`
--

CREATE TABLE `usertb` (
  `ID` int(5) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(15) DEFAULT NULL,
  `contact` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usertb`
--

INSERT INTO `usertb` (`ID`, `name`, `username`, `password`, `contact`) VALUES
(10, 'admin', 'admin', '123456', 75201854),
(11, 'James Opio', 'assAdmin', '123456', 752018585);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loantb`
--
ALTER TABLE `loantb`
  ADD PRIMARY KEY (`loanID`);

--
-- Indexes for table `membertb`
--
ALTER TABLE `membertb`
  ADD PRIMARY KEY (`memberID`);

--
-- Indexes for table `paytb`
--
ALTER TABLE `paytb`
  ADD PRIMARY KEY (`payID`);

--
-- Indexes for table `savetb`
--
ALTER TABLE `savetb`
  ADD PRIMARY KEY (`saveID`);

--
-- Indexes for table `usertb`
--
ALTER TABLE `usertb`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `loantb`
--
ALTER TABLE `loantb`
  MODIFY `loanID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `membertb`
--
ALTER TABLE `membertb`
  MODIFY `memberID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `paytb`
--
ALTER TABLE `paytb`
  MODIFY `payID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `savetb`
--
ALTER TABLE `savetb`
  MODIFY `saveID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `usertb`
--
ALTER TABLE `usertb`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
